_addon.author = 'Aragan'
_addon.name = 'AraCastHUD'
_addon.version = '1.2.4'

require 'common'

local alias = '__aracast_hud'
local values = {}
local visible = true
local order = { 'Weapons', 'Range', 'Offense', 'Hybrid', 'Ranged', 'WS', 'Casting', 'Idle', 'Shadow' }
local default_values = {
    Weapons = 'None',
    Range = 'None',
    Offense = 'Normal',
    Hybrid = 'Normal',
    Ranged = 'Normal',
    WS = 'Match',
    Casting = 'Normal',
    Idle = 'Normal',
    Shadow = 'Off',
}
local aliases = {
    weapons = 'Weapons',
    weapon = 'Weapons',
    weapongun = 'Range',
    range = 'Range',
    offense = 'Offense',
    offensemode = 'Offense',
    hybrid = 'Hybrid',
    hybridmode = 'Hybrid',
    ranged = 'Ranged',
    rangedmode = 'Ranged',
    ws = 'WS',
    weaponskillmode = 'WS',
    casting = 'Casting',
    castingmode = 'Casting',
    idle = 'Idle',
    idlemode = 'Idle',
    shadow = 'Shadow',
    autoshadow = 'Shadow',
    autoshadowmode = 'Shadow',
}
local hidden = {
    WS = { ['match'] = true },
    Shadow = { ['off'] = true },
}

local config_manager = AshitaCore:GetConfigurationManager()
local screen_width = config_manager:get_int32('boot_config', 'window_x', 1920)
local screen_height = config_manager:get_int32('boot_config', 'window_y', 1080)
local default_config = {
    values = {},
    visible = true,
    font = {
        family = 'Arial',
        size = 16,
        color = math.d3dcolor(255, 255, 255, 255),
        position = { 8, math.max(0, screen_height - 52) },
        background = math.d3dcolor(160, 0, 0, 0),
    },
}
local config = default_config
local last_position_x
local last_position_y
local position_save_pending = false
local position_changed_at = 0
local position_save_delay = 0.5

local function save_state()
    config.values = values
    config.visible = visible
    ashita.settings.save(_addon.path .. '/settings/aracasthud.json', config)
end

local function save_font_position(font)
    if not font then
        return
    end

    local position_x = font:GetPositionX()
    local position_y = font:GetPositionY()
    config.font.position = { position_x, position_y }
    last_position_x = position_x
    last_position_y = position_y
    position_save_pending = false
    save_state()
end

local function set_font_position(font, position_x, position_y)
    if not font then
        return false
    end

    position_x = tonumber(position_x)
    position_y = tonumber(position_y)
    if not position_x or not position_y then
        return false
    end

    local max_x = math.max(0, screen_width - 80)
    local max_y = math.max(0, screen_height - 52)
    position_x = math.max(0, math.min(max_x, math.floor(position_x + 0.5)))
    position_y = math.max(0, math.min(max_y, math.floor(position_y + 0.5)))
    font:SetPositionX(position_x)
    font:SetPositionY(position_y)
    save_font_position(font)
    return true
end

local function track_font_position(font)
    local position_x = font:GetPositionX()
    local position_y = font:GetPositionY()
    if position_x ~= last_position_x or position_y ~= last_position_y then
        config.font.position = { position_x, position_y }
        last_position_x = position_x
        last_position_y = position_y
        position_changed_at = os.clock()
        position_save_pending = true
    elseif position_save_pending and os.clock() - position_changed_at >= position_save_delay then
        position_save_pending = false
        save_state()
    end
end

local function canonical(name)
    return aliases[string.lower(tostring(name or ''))]
end

local function is_hidden(name, value)
    local mode_values = hidden[name]
    return mode_values and mode_values[string.lower(tostring(value or ''))] == true
end

local function build_text()
    local colored = {}
    local plain = {}
    for _, name in ipairs(order) do
        if values[name] ~= nil and not is_hidden(name, values[name]) then
            colored[#colored + 1] = name .. ': |cFFFFFF5F|' .. values[name] .. '|r'
            plain[#plain + 1] = name .. ': ' .. values[name]
        end
    end

    if #colored == 0 then
        return ''
    end
    if #table.concat(plain, '   ') * 8 <= screen_width - 24 then
        return table.concat(colored, '   ')
    end

    local split = math.ceil(#colored / 2)
    local first = {}
    local second = {}
    for index, text in ipairs(colored) do
        if index <= split then
            first[#first + 1] = text
        else
            second[#second + 1] = text
        end
    end
    return table.concat(first, '   ') .. '\n' .. table.concat(second, '   ')
end

local function get_font()
    return AshitaCore:GetFontManager():Get(alias)
end

ashita.register_event('load', function()
    config = ashita.settings.load_merged(_addon.path .. '/settings/aracasthud.json', config)
    values = {}
    for name, value in pairs(default_values) do
        values[name] = value
    end
    for name, value in pairs(config.values or {}) do
        values[name] = value
    end
    visible = config.visible ~= false
    local font = AshitaCore:GetFontManager():Create(alias)
    local position_x = tonumber(config.font.position[1]) or 8
    local position_y = tonumber(config.font.position[2]) or math.max(0, screen_height - 52)
    local max_x = math.max(0, screen_width - 80)
    local max_y = math.max(0, screen_height - 52)
    if position_x < 0 or position_x > max_x then
        position_x = 8
    end
    if position_y < 0 or position_y > max_y then
        position_y = max_y
    end
    config.font.position = { position_x, position_y }
    font:SetColor(config.font.color)
    font:SetFontFamily(config.font.family)
    font:SetFontHeight(config.font.size)
    font:SetPositionX(position_x)
    font:SetPositionY(position_y)
    last_position_x = position_x
    last_position_y = position_y
    position_save_pending = false
    font:SetText('')
    font:SetVisibility(false)
    local background = font:GetBackground()
    if background then
        background:SetColor(config.font.background)
        background:SetVisibility(true)
    end
end)

ashita.register_event('unload', function()
    local font = get_font()
    if font then
        save_font_position(font)
    else
        save_state()
    end
    AshitaCore:GetFontManager():Delete(alias)
end)

ashita.register_event('prerender', function()
    local font = get_font()
    if not font then
        return
    end
    track_font_position(font)
    local text = build_text()
    font:SetText(text)
    font:SetVisibility(visible and text ~= '')
end)

ashita.register_event('command', function(command, ntype)
    local args = command:args()
    if #args == 0 or (string.lower(args[1]) ~= '/achud' and string.lower(args[1]) ~= '/aracasthud') then
        return false
    end

    local action = string.lower(args[2] or 'toggle')
    if action == 'set' and args[3] and args[4] then
        local name = canonical(args[3])
        if name then
            values[name] = table.concat(args, ' ', 4)
            save_state()
        end
    elseif action == 'clear' then
        values = {}
        save_state()
    elseif action == 'pos' or action == 'position' then
        set_font_position(get_font(), args[3], args[4])
    elseif action == 'reset' then
        local font = get_font()
        set_font_position(font, 8, math.max(0, screen_height - 52))
    elseif action == 'hide' and args[3] and args[4] then
        local name = canonical(args[3])
        if name then
            hidden[name] = hidden[name] or {}
            hidden[name][string.lower(table.concat(args, ' ', 4))] = true
        end
    elseif action == 'show' and args[3] and args[4] then
        local name = canonical(args[3])
        if name and hidden[name] then
            hidden[name][string.lower(table.concat(args, ' ', 4))] = nil
        end
    else
        visible = not visible
        save_state()
    end
    return true
end)
