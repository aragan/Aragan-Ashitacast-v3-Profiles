_addon.author = 'Aragan'
_addon.name = 'AraCastHUD'
_addon.version = '1.0.0'

require 'common'

local alias = '__aracast_hud'
local values = {}
local visible = true
local order = { 'Weapons', 'Range', 'Offense', 'Hybrid', 'Ranged', 'WS', 'Casting', 'Idle' }
local aliases = {
    weapons = 'Weapons',
    weapon = 'Weapons',
    weapongun = 'Range',
    range = 'Range',
    offense = 'Offense',
    offensemode = 'Offense',
    hybrid = 'Hybrid',
    hybridmode = 'Hybrid',
    ranged = 'Ranged',
    rangedmode = 'Ranged',
    ws = 'WS',
    weaponskillmode = 'WS',
    casting = 'Casting',
    castingmode = 'Casting',
    idle = 'Idle',
    idlemode = 'Idle',
}

local config_manager = AshitaCore:GetConfigurationManager()
local screen_width = config_manager:get_int32('boot_config', 'window_x', 1920)
local screen_height = config_manager:get_int32('boot_config', 'window_y', 1080)
local default_config = {
    font = {
        family = 'Arial',
        size = 16,
        color = math.d3dcolor(255, 255, 255, 255),
        position = { 8, math.max(0, screen_height - 52) },
        background = math.d3dcolor(160, 0, 0, 0),
    },
}
local config = default_config

local function canonical(name)
    return aliases[string.lower(tostring(name or ''))]
end

local function build_text()
    local colored = {}
    local plain = {}
    for _, name in ipairs(order) do
        if values[name] ~= nil then
            colored[#colored + 1] = name .. ': |cFFFFFF5F|' .. values[name] .. '|r'
            plain[#plain + 1] = name .. ': ' .. values[name]
        end
    end

    if #colored == 0 then
        return ''
    end
    if #table.concat(plain, '   ') * 8 <= screen_width - 24 then
        return table.concat(colored, '   ')
    end

    local split = math.ceil(#colored / 2)
    local first = {}
    local second = {}
    for index, text in ipairs(colored) do
        if index <= split then
            first[#first + 1] = text
        else
            second[#second + 1] = text
        end
    end
    return table.concat(first, '   ') .. '\n' .. table.concat(second, '   ')
end

local function get_font()
    return AshitaCore:GetFontManager():Get(alias)
end

ashita.register_event('load', function()
    config = ashita.settings.load_merged(_addon.path .. '/settings/aracasthud.json', config)
    local font = AshitaCore:GetFontManager():Create(alias)
    font:SetColor(config.font.color)
    font:SetFontFamily(config.font.family)
    font:SetFontHeight(config.font.size)
    font:SetPositionX(config.font.position[1])
    font:SetPositionY(config.font.position[2])
    font:SetText('')
    font:SetVisibility(false)
    local background = font:GetBackground()
    if background then
        background:SetColor(config.font.background)
        background:SetVisibility(true)
    end
end)

ashita.register_event('unload', function()
    local font = get_font()
    if font then
        config.font.position = { font:GetPositionX(), font:GetPositionY() }
        ashita.settings.save(_addon.path .. '/settings/aracasthud.json', config)
    end
    AshitaCore:GetFontManager():Delete(alias)
end)

ashita.register_event('prerender', function()
    local font = get_font()
    if not font then
        return
    end
    local text = build_text()
    font:SetText(text)
    font:SetVisibility(visible and text ~= '')
end)

ashita.register_event('command', function(command, ntype)
    local args = command:args()
    if #args == 0 or (string.lower(args[1]) ~= '/achud' and string.lower(args[1]) ~= '/aracasthud') then
        return false
    end

    local action = string.lower(args[2] or 'toggle')
    if action == 'set' and args[3] and args[4] then
        local name = canonical(args[3])
        if name then
            values[name] = table.concat(args, ' ', 4)
        end
    elseif action == 'clear' then
        values = {}
    elseif action == 'reset' then
        local font = get_font()
        if font then
            font:SetPositionX(8)
            font:SetPositionY(math.max(0, screen_height - 52))
        end
    else
        visible = not visible
    end
    return true
end)

