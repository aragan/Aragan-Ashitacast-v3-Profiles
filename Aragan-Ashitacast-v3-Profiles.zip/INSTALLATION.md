# Aragan Ashitacast v3 Profiles

Author and maintainer: **Aragan**

This package contains Aragan XML profiles for all 22 jobs, the Ashita v3 `AraCastHUD` addon, the rename tool, startup commands, and a HUD reference image. The Ashitacast plugin itself is not included.

## Installation

1. Install the Ashitacast plugin for Ashita v3.
2. Extract this archive into the Ashita v3 root folder and keep the included paths.
3. Run `config/Ashitacast/Rename.bat` and enter your FFXI character name.
4. Add the lines from `scripts/aragan-ashitacast.txt` to your Ashita startup script, or load the plugin and addon manually.
5. In game, use `/ac reload` after changing a profile.

The profiles automatically select the active character file after it has the correct character name.

## HUD And Modes

`AraCastHUD` displays the active weapon and all current modes at the bottom of the screen. Use `/achud` to show or hide it and `/achud reset` to restore its position. The reference image is `images/hud-bottom-example.png`.

Edit `addons/aracasthud/aracasthud.lua` to change the displayed mode order, hidden values, defaults, color, font, size, background, or initial position. Profile mode values and commands are defined in each `config/Ashitacast/<Character>_<JOB>.xml` file.

Key bindings are in each XML profile's `<load>` and `<unload>` sections. Ashita binding prefixes are `^` for Ctrl, `!` for Alt, `@` for Windows, and `+` for Shift in Ashita v3. Keep the matching `/unbind` entry when changing a key.

### Style Modes

- `Windows+Ctrl+F1` or `/aragan_toggle_autolockstyle` toggles `AutoLockstyle`.
- `Windows+Ctrl+F7` or `/aragan_toggle_autostylemode` toggles `Autostylemode`.
- When either mode changes from `Off` to `On`, the profile runs `/lockstyleset 1`.
- Turning either mode off does not change the current appearance, and Style 1 is not applied merely by loading a job.
- `/lockstyleset 1` can always be used manually.

## Support And Repositories

- Discord: https://discord.gg/TskRzqGUMG
- Profiles: https://github.com/aragan/Aragan-Ashitacast-v3-Profiles
- Ashita v4 addons: https://github.com/aragan/AshitaV4-addons
- Ashita v3 addons: https://github.com/aragan/AshitaV3-addons
- Ashitacast v3: https://github.com/aragan/Ashitacast-v3
