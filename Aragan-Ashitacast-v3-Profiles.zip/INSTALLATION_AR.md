# دليل تركيب ملفات Aragan لـ Ashitacast 3

## ما الذي تحتويه هذه الحزمة؟

تحتوي الحزمة على ملفات XML الأساسية لـ22 جوبًا. ملفات XML ليست Plugin Ashitacast نفسه، والـHUD السفلي موجود في إضافة مستقلة اسمها `aracasthud`.

## المتطلبات

1. تثبيت Ashita 3.
2. وجود Plugin Ashitacast الخاص بـAshita 3:

```text
ashitav3\plugins\Ashitacast.dll
```

3. وجود إضافة HUD الخاصة بـAshita 3:

```text
ashitav3\addons\aracasthud\aracasthud.lua
```

4. استخدم ملفات وإضافات Ashita 3 فقط؛ لا تستبدلها بنسخ Ashita 4.

## طريقة التركيب

1. انسخ ملفات الجوبات الأساسية إلى:

```text
ashitav3\config\Ashitacast
```

2. أعد تسمية الملفات من `Aragan_JOB.xml` إلى اسم شخصيتك، مثل:

```text
FriendName_WAR.xml
FriendName_COR.xml
FriendName_BRD.xml
```

3. يمكن تشغيل `Rename.bat` الموجود في المجلد.
4. اكتب `Aragan` عند طلب النص القديم.
5. اكتب اسم الشخصية الجديد عند طلب النص الجديد.
6. الأداة تغيّر أسماء الملفات في المجلد الحالي فقط ولا تغيّر محتويات XML.

## أوامر التشغيل

```text
/load ashitacast
/addon load aracasthud
```

لإعادة تحميل ملف الجوب:

```text
/ac reload
```

## التشغيل التلقائي

أضف السطرين التاليين إلى `ashitav3\scripts\default.txt`:

```text
/addon load aracasthud
/load ashitacast
```

## اختبار التركيب

1. ادخل بالشخصية بعد إعادة تسمية الملفات.
2. تأكد من تحميل XML الخاص بالجوب دون أخطاء.
3. تأكد من ظهور HUD السفلي.
4. جرّب الوقوف والجلوس واستخدام سحر أو Ability.
5. جرّب مفاتيح المودات وتأكد أن قيمة المود تتغير في HUD.

## مشاكل شائعة

- ملف الجوب لا يتحمل: يجب أن يكون الاسم `CharacterName_JOB.xml`.
- HUD لا يظهر: يجب تثبيت وتحميل `aracasthud` الخاص بـAshita 3.
- خطأ XML: لا تستخدم نسخة تجريبية أو backup بدل الملف الأساسي.
- بعض القطع لا تُلبس: يجب توفر القطع والـaugments نفسها عند اللاعب.
- أوامر Singer وCCSV وCancel والأتمتة الخارجية تحتاج إضافاتها الخاصة.
- لا تستخدم `Ashitacast.dll` أو `aracasthud` الخاصين بـAshita 4 داخل Ashita 3.

## الجوبات الأساسية المشمولة

```text
WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU COR PUP DNC SCH GEO RUN
```

انسخ فقط الملفات الأساسية المسماة `Aragan_JOB.xml`. تجاهل الملفات القديمة التي تحتوي أرقامًا أو كلمات مثل `backup` و`updated` عند تجهيز حزمة لصديق.

## المؤلف وروابط Aragan

- اسم الحزمة: **Aragan Ashitacast 3**
- مؤلف حزمة الجوبات والتحويلات والـHUD والتعديلات: **Aragan**
- مؤلف Plugin Ashitacast الأصلي: **Thorny**
- سيرفر Discord الخاص بـAragan: [https://discord.gg/TskRzqGUMG](https://discord.gg/TskRzqGUMG)
- إضافات Ashita 4: [https://github.com/aragan/AshitaV4-addons](https://github.com/aragan/AshitaV4-addons)
- إضافات Ashita 3: [https://github.com/aragan/AshitaV3-addons](https://github.com/aragan/AshitaV3-addons)
- ملفات Ashitacast 3: [https://github.com/aragan/Ashitacast-v3](https://github.com/aragan/Ashitacast-v3)
