@echo off
setlocal enableDelayedExpansion
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Process -FilePath '%~f0' -Verb RunAs } catch { exit 1 }"
  if errorlevel 1 (
    echo Administrator permission was not granted.
    pause
  )
  exit /b
)

set /p "string1=Enter the sequence to be replaced : "
if not defined string1 (
  echo Old sequence cannot be empty.
  pause
  exit /b 1
)
set /p "string2=Enter the new sequence  : "
set /a renamed=0
for %%F in (*%string1%*.*) do (
  if exist "%%F" (
    set "filename=%%F"
    set "newname=!filename:%string1%=%string2%!"
    if not "!filename!"=="!newname!" (
      ren "!filename!" "!newname!"
      if not errorlevel 1 set /a renamed+=1
    )
  )
)
echo Renamed !renamed! file(s) in:
echo %~dp0
pause
