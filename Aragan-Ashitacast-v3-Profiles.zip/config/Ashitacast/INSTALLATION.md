# Aragan Ashitacast v3 Profiles

Author and maintainer: **Aragan**

This package contains XML profiles for all 22 jobs, the Ashita v3 AraCastHUD addon, the rename tool, startup commands, 169 shared key bindings, and a HUD reference image. The Ashitacast plugin itself is not included.

## Installation

1. Install the Ashitacast plugin for Ashita v3.
2. Extract this archive into the Ashita v3 root folder and keep the included paths.
3. Run config/Ashitacast/Rename.bat and enter the FFXI character name.
4. Add scripts/aragan-ashitacast.txt to the Ashita startup script, or load Ashitacast and AraCastHUD manually.
5. Use /ac reload after profile edits.

## Mode and key counts

- 22 job profiles.
- 143 distinct package-wide Aragan_ state variables.
- **135 user-facing Aragan mode/state names** after 8 internal lock/helper variables are removed.
- **27 shared implemented modes**, plus original job-specific XML modes.
- **169 shared key bindings**.
- A single job profile contains only the modes relevant to that job; native XML modes are additional and are not included in the Aragan_ count.

## Core commands

- /ac reload reloads the active XML profile.
- /weapons, /offense, /hybrid, /rangedmode, /wsmode, /castingmode, and /idlemode cycle supported core modes.
- /aragan_toggle_autolockstyle toggles AutoLockstyle.
- /aragan_toggle_autostylemode toggles Autostylemode.
- /lockstyleset 1 manually applies style set 1.
- /aragan_key_001 through /aragan_key_169 execute the same actions as the key table below.

## AraCastHUD commands

- /achud or /aracasthud toggles visibility.
- /achud pos X Y moves the HUD to exact coordinates.
- /achud reset restores the default bottom position.
- /achud set MODE VALUE sets a displayed HUD value.
- /achud hide MODE VALUE hides one displayed value.
- /achud show MODE VALUE shows that value again.
- /achud clear clears received HUD values.
- /achud redproc on|off|toggle controls the HUD Red Proc listener.

## Modifier syntax

- ^ = Ctrl
- ! = Alt
- @ = Windows
- The current XML uses ~ for Shift in the shared bindings. If the installed Ashita v3 Bind plugin rejects ~, change it to the Shift prefix supported by that Bind build.
- Combined prefixes mean that all listed modifiers are held.

## Complete Aragan mode registry

| Mode | Purpose | Status |
|---|---|---|
| `Absorbs` | Selects the DRK Absorb spell. | Job/profile-dependent |
| `AllseenmsgMode` | Selects the A ll se en ms gM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `AltStep` | Selects the A lt St ep value used by job-specific rules or external integration. | Job/profile-dependent |
| `AmbushMode` | Selects the A mb us hM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `Animators` | Selects the PUP animator. | Job/profile-dependent |
| `Ascws` | Selects a skillchain/WS value used by ASC integration. | Job/profile-dependent |
| `AutoAbsorttpaspirSpam` | Controls profile-specific Absorb-TP/Aspir repetition. | Job/profile-dependent |
| `AutoAcceptRaiseMode` | Controls profile-specific automatic Raise acceptance. | Job/profile-dependent |
| `AutoAPMode` | Controls the imported A ut oA PM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoArts` | Activates Light Arts when SCH arts are missing. | Shared active |
| `AutoBaraMode` | Controls the imported A ut oB ar aM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoBarStatus` | Selects the automatic Bar-status spell. | Job/profile-dependent |
| `AutoBoost` | Controls the imported A ut oB oo st feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoBoostStat` | Selects the automatic Boost-stat spell. | Job/profile-dependent |
| `AutoBuffMode` | Runs the job/profile automatic buff sequence. | Shared active |
| `AutoBuyAuctionHouseMod` | Controls profile-specific Auction House buying automation. | Job/profile-dependent |
| `AutoCallPet` | Controls the imported A ut oC al lP et feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoCleanupMode` | Controls profile-specific cleanup behavior. | Job/profile-dependent |
| `AutoConvert` | Controls the imported A ut oC on ve rt feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoCureMode` | Uses Curing Waltz III or Cure IV when HP is below the configured shared threshold. | Shared active |
| `Autodebugemode` | Controls the imported A ut od eb ug em od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoDefenseMode` | Controls profile-specific automatic defense switching. | Job/profile-dependent |
| `AutoDeployMode` | Uses Deploy for an active PUP automaton against a monster target. | Shared active |
| `AutoDropItemsMode` | Controls profile-specific automatic item dropping. | Job/profile-dependent |
| `AutoEffusionMode` | Controls the imported A ut oE ff us io nM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoEngageMode` | Controls profile-specific automatic engagement. | Job/profile-dependent |
| `AutoFarmMode` | Controls profile-specific farming automation. | Job/profile-dependent |
| `AutoFavor` | Controls the imported A ut oF av or feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoFightMode` | Controls the imported A ut oF ig ht Mo de feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoFoodMode` | Uses the configured automatic food when the Food buff is absent. | Shared active |
| `AutogearbuffMode` | Controls the imported A ut og ea rb uf fM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoGeoAbilities` | Controls the imported A ut oG eo Ab il it ie s feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoHasteMode` | Casts Haste when the supported mage job does not have Haste. | Shared active |
| `AutoinfoNMMode` | Controls the imported A ut oi nf oN MM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `Autojoinptmode` | Controls the imported A ut oj oi np tm od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoJumpMode` | Controls profile-specific automatic Jump behavior. | Job/profile-dependent |
| `AutoLockstyle` | Applies lockstyle set 1 when enabled and during supported profile/job refresh events. | Shared active |
| `AutoLoggerMode` | Controls profile-specific logging. | Job/profile-dependent |
| `AutoMagicBurstMode` | Controls profile-specific automatic magic-burst behavior. | Job/profile-dependent |
| `AutoMajesty` | Controls the imported A ut oM aj es ty feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoMedicineMode` | Uses Panacea or Remedy once when a supported debuff first appears. | Shared active |
| `AutoNukeMode` | Runs the profile automatic nuke action against a valid monster target. | Shared active |
| `AutoOtherTargetWS` | Controls the imported A ut oO th er Ta rg et WS feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoPDLwstmode` | Controls the imported A ut oP DL ws tm od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoPetMode` | Controls profile-specific automatic pet behavior. | Job/profile-dependent |
| `AutoPuppetMode` | Controls the imported A ut oP up pe tM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoRA` | Controls the imported A ut oR A feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoRepairMode` | Controls profile-specific automatic PUP Repair behavior. | Job/profile-dependent |
| `AutoReraiseMode` | Controls profile-specific automatic Reraise behavior. | Job/profile-dependent |
| `AutoRuneMode` | Maintains the selected rune for RUN main or sub. | Shared active |
| `AutoSambaMode` | Uses the selected Samba while DNC main or sub is engaged. | Shared active |
| `AutoShadowMode` | Maintains Utsusemi shadows for NIN main or sub while stationary. | Shared active |
| `AutoSongMode` | Controls the imported A ut oS on gM od e feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutostepssubjobMode` | Controls the imported A ut os te ps su bj ob Mo de feature. Execution depends on the current job profile. | Job/profile-dependent |
| `AutoStunMode` | Controls profile-specific automatic Stun behavior. | Job/profile-dependent |
| `Autostylemode` | Automatically reapplies lockstyle set 1 after profile or subjob changes. | Shared active |
| `AutoSubMode` | Maintains Sublimation for SCH main or sub. | Shared active |
| `AutoTankMode` | Controls profile-specific automatic tank behavior. | Job/profile-dependent |
| `AutoTomahawkMode` | Controls profile-specific automatic Tomahawk behavior. | Job/profile-dependent |
| `AutoTPReductionMode` | Controls profile-specific TP-reduction behavior. | Job/profile-dependent |
| `AutoTradeMode` | Controls profile-specific automatic trading. | Job/profile-dependent |
| `AutoTrustMode` | Runs the automatic Trust-fill action while idle and stationary. | Shared active |
| `AutoWSMode` | Executes the selected automatic WS when combat, TP, target, and range checks pass. | Shared active |
| `AutoWSRestore` | Controls the imported A ut oW SR es to re feature. Execution depends on the current job profile. | Job/profile-dependent |
| `Avatars` | Selects the SMN avatar value used by profile commands. | Job/profile-dependent |
| `BarfawcMode` | Selects the B ar fa wc Mo de behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `BarStatus` | Selects the B ar St at us value used by job-specific rules or external integration. | Job/profile-dependent |
| `BloodMode` | Controls Blood-related job/profile behavior. | Job/profile-dependent |
| `CancelStoneskin` | Controls profile-specific Stoneskin cancellation. | Job/profile-dependent |
| `Capacity` | Controls Capacity Point farming state. | Job/profile-dependent |
| `CarnMode` | Controls Carnwenhan use rules in supported profiles. | Job/profile-dependent |
| `CastingMode` | Selects the spell-casting gear variant. | Shared active |
| `CompensatorMode` | Controls Compensator use rules in supported profiles. | Job/profile-dependent |
| `CorrelationMode` | Selects neutral or favorable BST pet correlation handling. | Job/profile-dependent |
| `CraftingMode` | Selects the crafting discipline. | Job/profile-dependent |
| `CraftQuality` | Selects the requested crafting quality mode. | Job/profile-dependent |
| `CurrentStep` | Selects the C ur re nt St ep value used by job-specific rules or external integration. | Job/profile-dependent |
| `DanceStance` | Selects the D an ce St an ce value used by job-specific rules or external integration. | Job/profile-dependent |
| `DarknessMode` | Controls Darkness-specific profile behavior. | Job/profile-dependent |
| `DefenseDownMode` | Selects the D ef en se Do wn Mo de behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `DefenseMode` | Selects the active defense family, such as physical, magical, or resist. | Job/profile-dependent |
| `DisplayMode` | Controls the converted profile display state. | Job/profile-dependent |
| `DrainSwapWeaponMode` | Controls weapon swapping for Drain in supported profiles. | Job/profile-dependent |
| `DynamisMode` | Controls Dynamis-specific profile behavior. | Job/profile-dependent |
| `ElementalMode` | Selects elemental profile behavior or elemental gear. | Job/profile-dependent |
| `Enfeeb` | Selects the E nf ee b value used by job-specific rules or external integration. | Job/profile-dependent |
| `Enfeebling` | Selects the E nf ee bl in g value used by job-specific rules or external integration. | Job/profile-dependent |
| `ExtraDefenseMode` | Selects an additional defensive gear overlay. | Job/profile-dependent |
| `ExtraMeleeMode` | Selects an additional melee gear overlay. | Job/profile-dependent |
| `HaltOnTp` | Selects the H al tO nT p value used by job-specific rules or external integration. | Job/profile-dependent |
| `HippoMode` | Selects the H ip po Mo de behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `HybridMode` | Adds a defensive or hybrid overlay to the engaged set. | Shared active |
| `IdleMode` | Selects the idle gear set. | Shared active |
| `JugMode` | Selects the BST jug pet. | Job/profile-dependent |
| `Kiting` | Enables the movement/kiting equipment overlay. | Job/profile-dependent |
| `LearningMode` | Selects the L ea rn in gM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `LuzafRing` | Selects the L uz af Ri ng value used by job-specific rules or external integration. | Job/profile-dependent |
| `MagicalDefenseMode` | Selects the magic-defense equipment variant. | Job/profile-dependent |
| `MagicBurst` | Selects the M ag ic Bu rs t value used by job-specific rules or external integration. | Job/profile-dependent |
| `MainStep` | Selects the M ai nS te p value used by job-specific rules or external integration. | Job/profile-dependent |
| `ManaWallMode` | Selects the M an aW al lM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `NakedMode` | Controls the profile naked/no-gear state. | Job/profile-dependent |
| `NeverDieMode` | Controls the imported emergency-survival state. | Job/profile-dependent |
| `NM` | Controls NM-specific profile behavior. | Job/profile-dependent |
| `NotifyBuffs` | Controls profile-specific buff notifications. | Job/profile-dependent |
| `OdyAutowsMode` | Controls the Odyssey automatic-WS state. | Job/profile-dependent |
| `OffenseMode` | Selects the engaged TP/offense gear set. | Shared active |
| `passive` | Selects a passive gear overlay used by the current job profile. | Job/profile-dependent |
| `pctargetmode` | Controls whether supported automation may select player-character targets. | Job/profile-dependent |
| `PetEnmityGear` | Enables the pet enmity equipment overlay. | Job/profile-dependent |
| `PetMode` | Selects the pet role or pet equipment family. | Job/profile-dependent |
| `PetWSGear` | Enables pet weapon-skill gear handling. | Job/profile-dependent |
| `PhysicalDefenseMode` | Selects the physical-defense equipment variant. | Job/profile-dependent |
| `QDMode` | Selects the Q DM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `RangedMode` | Selects the ranged-attack gear variant. | Shared active |
| `RecoverMode` | Selects the profile recovery behavior. | Job/profile-dependent |
| `Redprocmode` | NIN/WAR only: reads Abyssea red-proc hints and selects the matching proc weapon group. | Shared active; NIN/WAR only |
| `ReEquip` | Controls profile-specific forced re-equipping. | Job/profile-dependent |
| `RefineWaltz` | Controls profile-specific Waltz selection refinement. | Job/profile-dependent |
| `ResistDefenseMode` | Selects the resistance-focused defense variant. | Job/profile-dependent |
| `RestingMode` | Selects the R es ti ng Mo de behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `RewardMode` | Selects the BST Reward item tier. | Job/profile-dependent |
| `Rollset` | Selects the COR roll preset. | Job/profile-dependent |
| `RP` | Controls RP-related profile behavior. | Job/profile-dependent |
| `RuneElement` | Selects Ignis, Gelus, Flabra, Tellus, Sulpor, Unda, Lux, or Tenebrae for AutoRuneMode. | Shared active |
| `SalvageMode` | Controls Salvage-specific profile behavior. | Job/profile-dependent |
| `selectnpctargets` | Controls whether supported automation may select NPC targets. | Job/profile-dependent |
| `shield` | Selects a shield value used by the current profile. | Job/profile-dependent |
| `ShieldMode` | Selects the shield set or named shield. | Job/profile-dependent |
| `Singer` | Selects a BRD singer/preset profile. | Job/profile-dependent |
| `Skillchainermode` | Controls integration with the Skillchainer workflow. | Job/profile-dependent |
| `SkipProcWeapons` | Controls whether proc weapon candidates may be skipped by supported proc logic. | Job/profile-dependent |
| `SleepMode` | Selects normal or maximum-duration sleep gear. | Job/profile-dependent |
| `SmartAutoShoutMode` | Selects the S ma rt Au to Sh ou tM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `SmartMode` | Selects the S ma rt Mo de behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `Songset` | Selects the BRD song preset. | Job/profile-dependent |
| `Spellset` | Selects a profile spell preset. | Job/profile-dependent |
| `SrodaBelt` | Controls use of the Sroda Belt gear option. | Job/profile-dependent |
| `SrodaNecklace` | Controls use of the Sroda Necklace gear option. | Job/profile-dependent |
| `stance` | Selects the job stance value. | Job/profile-dependent |
| `StormSurge` | Controls SCH Stormsurge-related profile behavior. | Job/profile-dependent |
| `SubtleBlowMode` | Selects the S ub tl eB lo wM od e behavior or gear variant. Exact effects depend on the current job profile. | Job/profile-dependent |
| `TankAutoDefense` | Controls the imported tank defense state. | Job/profile-dependent |
| `TargetMode` | Controls profile-specific target selection behavior. | Job/profile-dependent |
| `treasuremode` | Selects the Treasure Hunter handling state. | Job/profile-dependent |
| `UnlockWeapons` | Controls whether profile rules may release weapon locks. | Job/profile-dependent |
| `UseAltStep` | Selects the U se Al tS te p value used by job-specific rules or external integration. | Job/profile-dependent |
| `UseCustomTimers` | Controls custom timer integration. | Job/profile-dependent |
| `VWprocmode` | Controls Voidwatch proc mode. | Job/profile-dependent |
| `WarpRingQueued` | Selects the W ar pR in gQ ue ue d value used by job-specific rules or external integration. | Job/profile-dependent |
| `Weapongun` | Selects the ranged weapon; normally used by COR and RNG. | Shared active; COR/RNG profiles |
| `WeaponLock` | Controls whether the selected weapon is preserved by profile rules. | Job/profile-dependent |
| `Weapons` | Selects the main/sub weapon set. | Shared active |
| `WeaponskillMode` | Selects the weapon-skill gear variant; it does not execute a WS by itself. | Shared active |

## Complete key and command reference

External commands such as /aws, /asc, /trust, /po, /smrt, and /gzc require their related addon.

| Key | Direct command | Action |
|---|---|---|
| `f9` | `/aragan_key_001` | Cycle OffenseMode |
| `^f9` | `/aragan_key_002` | Cycle HybridMode |
| `!f9` | `/aragan_key_003` | Cycle WeaponskillMode |
| `f4` | `/aragan_key_004` | Cycle ElementalMode |
| `!f5` | `/aragan_key_005` | Cycle WeaponskillMode |
| `!f10` | `/aragan_key_006` | Toggle Kiting |
| `!f11` | `/aragan_key_007` | Cycle MagicalDefenseMode; Set DefenseMode = Magical |
| `f11` | `/aragan_key_008` | Cycle CastingMode |
| `^f12` | `/aragan_key_009` | Cycle ResistDefenseMode |
| `f12` | `/aragan_key_010` | Cycle IdleMode; Reset DefenseMode |
| `!f12` | `/aragan_key_011` | Reset DefenseMode; Reset IdleMode; Reset passive; Reset CraftingMode; Reset CraftQuality |
| `^f11` | `/aragan_key_012` | Cycle ExtraMeleeMode |
| `delete` | `/aragan_key_013` | Run /zonetimer reset |
| `^pagedown` | `/aragan_key_014` | Run /autoitem toggle |
| `^delete` | `/aragan_key_015` | Run /aws toggle; Set AutoWSMode = false |
| `^insert` | `/aragan_key_016` | Run /aws reload |
| `~d` | `/aragan_key_017` | Cycle DefenseDownMode |
| `!insert` | `/aragan_key_018` | Run /smrt on; Run /smrt |
| `!delete` | `/aragan_key_019` | Run /smrt off |
| `^4` | `/aragan_key_020` | Toggle AutoAbsorttpaspirSpam |
| `^7` | `/aragan_key_021` | Toggle AutoWSRestore |
| `!backspace` | `/aragan_key_022` | Run /automb toggle |
| `^w` | `/aragan_key_023` | Run /wave |
| `!f2` | `/aragan_key_024` | Toggle TankAutoDefense |
| `!f3` | `/aragan_key_025` | Toggle AutoTankMode |
| `!f4` | `/aragan_key_026` | Toggle AutoDefenseMode |
| `f5` | `/aragan_key_027` | Toggle AutoWSMode; Run /aws off |
| `@f1` | `/aragan_key_028` | Toggle AutoEngageMode; Run /gzc auto_point |
| `@f2` | `/aragan_key_029` | Toggle AutoBuffMode |
| `@f3` | `/aragan_key_030` | Toggle AutoTrustMode |
| `^/` | `/aragan_key_031` | Disable automatic equipment changes |
| `!/` | `/aragan_key_032` | Enable automatic equipment changes |
| `@x` | `/aragan_key_033` | Toggle RP |
| `@z` | `/aragan_key_034` | Toggle Capacity |
| `!c` | `/aragan_key_035` | Set Weapons = None; Cycle CraftingMode |
| `^c` | `/aragan_key_036` | Cycle CraftQuality |
| `!1` | `/aragan_key_037` | Toggle AutoSambaMode |
| `!2` | `/aragan_key_038` | Toggle AutoShadowMode |
| `!3` | `/aragan_key_039` | Toggle AutoRuneMode |
| `!4` | `/aragan_key_040` | Cycle passive |
| `@4` | `/aragan_key_041` | Cycle passive backward |
| `!5` | `/aragan_key_042` | Toggle stance |
| `^1` | `/aragan_key_043` | Toggle AutoNukeMode |
| `^f2` | `/aragan_key_044` | Set AutoBuffMode = off |
| `^2` | `/aragan_key_045` | Toggle AutoSubMode |
| `^3` | `/aragan_key_046` | Cycle RuneElement |
| `^f1` | `/aragan_key_047` | Toggle AutoStunMode |
| `@1` | `/aragan_key_048` | Toggle AutoCleanupMode |
| `@2` | `/aragan_key_049` | Run /echo [Aragan] Buffup command requested; Run /p buffup") |
| `@3` | `/aragan_key_050` | Cycle RecoverMode |
| `@5` | `/aragan_key_051` | Toggle AutoFoodMode |
| `@7` | `/aragan_key_052` | Toggle TargetMode |
| `!w` | `/aragan_key_053` | Toggle WeaponLock |
| `^f7` | `/aragan_key_054` | Toggle AutoSubMode |
| `!7` | `/aragan_key_055` | Toggle AutoAcceptRaiseMode |
| `!8` | `/aragan_key_056` | Toggle SkipProcWeapons |
| `!9` | `/aragan_key_057` | Toggle AutogearbuffMode |
| `!0` | `/aragan_key_058` | Toggle Autojoinptmode |
| `^0` | `/aragan_key_059` | Toggle AutoDropItemsMode |
| `^-` | `/aragan_key_060` | Toggle selectnpctargets |
| `!-` | `/aragan_key_061` | Cycle pctargetmode |
| `~p` | `/aragan_key_062` | Run /put storage slip* case all |
| `!,` | `/aragan_key_063` | Run /put * sack all; Run /put * Satchel all |
| `!.` | `/aragan_key_064` | Run /put * Wardrobe4 all |
| `^.` | `/aragan_key_065` | Run /get storage slip* all; Run /wait 1; Run /po r |
| `^,` | `/aragan_key_066` | Run /addon reload PorterPacker; Run /wait 1; Run /get storage slip* all; Run /wait 1; Run /po r a |
| `^]` | `/aragan_key_067` | Run /get storage slip* all; Run /wait 1; Run /po pack |
| `^[` | `/aragan_key_068` | Run /get storage slip* all; Run /wait 1; Run /addon reload PorterPacker; Run /wait 1; Run /po p a |
| `!o` | `/aragan_key_069` | Run /put storage slip* case all; Run /wait .3; Run /echo [Aragan] gs org is Windower-only; Run /wait 3; Run /echo [Aragan] gs validate is Windower-only |
| `!m` | `/aragan_key_070` | Toggle AutoMedicineMode |
| `~s` | `/aragan_key_071` | Toggle AutoLoggerMode; Toggle NotifyBuffs |
| `~f1` | `/aragan_key_072` | Run /asc |
| `~f2` | `/aragan_key_073` | Run /asc toggle |
| `~f3` | `/aragan_key_074` | Run /asc open |
| `~f4` | `/aragan_key_075` | Cycle ascws |
| `~f5` | `/aragan_key_076` | Cycle ascws backward |
| `~f6` | `/aragan_key_077` | Run /asc r |
| `~f7` | `/aragan_key_078` | Run /asc pr |
| `%~1` | `/aragan_key_079` | Run /asc c 1 |
| `%~2` | `/aragan_key_080` | Run /asc c 2 |
| `%~3` | `/aragan_key_081` | Run /asc c 3 |
| `%~4` | `/aragan_key_082` | Run /asc c 4 |
| `~q` | `/aragan_key_083` | Run ! |
| `~w` | `/aragan_key_084` | Run @ |
| `~e` | `/aragan_key_085` | Run # |
| `~r` | `/aragan_key_086` | Run $ |
| `~insert` | `/aragan_key_087` | Run /addon load Skillchainer; Run /Skillchainer pause |
| `~delete` | `/aragan_key_088` | Run /addon unload Skillchainer |
| `~home` | `/aragan_key_089` | Run /Skillchainer pause |
| `!home` | `/aragan_key_092` | Run /addon load trust |
| `!end` | `/aragan_key_093` | Run /addon unload trust |
| `^home` | `/aragan_key_094` | Run /trust toggle |
| `home` | `/aragan_key_095` | Run /addon load autobuff |
| `end` | `/aragan_key_096` | Run /addon unload autobuff |
| `^@!f12` | `/aragan_key_097` | Run /lac reload; Run /gzc auto_point |
| `^@!f10` | `/aragan_key_098` | Run /gzc auto_point |
| `pageup` | `/aragan_key_099` | Run /ata toggle; Toggle AutoEngageMode; Run /gzc auto_point |
| `!^f1` | `/aragan_key_100` | Toggle AllseenmsgMode |
| `!^f2` | `/aragan_key_101` | Cycle Ascws |
| `!^f3` | `/aragan_key_102` | Toggle AutoArts |
| `!^f4` | `/aragan_key_103` | Cycle AutoBarStatus |
| `!^f5` | `/aragan_key_104` | Toggle AutoBuyAuctionHouseMod |
| `!^f6` | `/aragan_key_105` | Toggle AutoCureMode |
| `!^f8` | `/aragan_key_106` | Cycle Autodebugemode |
| `!^f9` | `/aragan_key_107` | Toggle AutoDeployMode |
| `!^f10` | `/aragan_key_108` | Toggle AutoFarmMode |
| `!^f11` | `/aragan_key_109` | Toggle AutoHasteMode |
| `!^f12` | `/aragan_key_110` | Toggle AutoinfoNMMode |
| `@^f1` | `/aragan_key_111` | Toggle AutoLockstyle |
| `@^f2` | `/aragan_key_112` | Toggle AutoMagicBurstMode |
| `@^f3` | `/aragan_key_113` | Toggle AutoOtherTargetWS |
| `@^f4` | `/aragan_key_114` | Toggle AutoPDLwstmode |
| `@^f5` | `/aragan_key_115` | Toggle AutoPetMode |
| `@^f6` | `/aragan_key_116` | Toggle AutostepssubjobMode |
| `@^f7` | `/aragan_key_117` | Toggle Autostylemode |
| `@^f8` | `/aragan_key_118` | Toggle AutoTomahawkMode |
| `@^f9` | `/aragan_key_119` | Toggle AutoTPReductionMode |
| `@^f10` | `/aragan_key_120` | Toggle AutoTradeMode |
| `@^f11` | `/aragan_key_121` | Cycle Avatars |
| `@^f12` | `/aragan_key_122` | Toggle BloodMode |
| `@!f1` | `/aragan_key_123` | Toggle CancelStoneskin |
| `@!f2` | `/aragan_key_124` | Toggle DarknessMode |
| `@!f3` | `/aragan_key_125` | Toggle DisplayMode |
| `@!f4` | `/aragan_key_126` | Cycle DrainSwapWeaponMode |
| `@!f5` | `/aragan_key_127` | Toggle DynamisMode |
| `@!f6` | `/aragan_key_128` | Toggle NakedMode |
| `@!f7` | `/aragan_key_129` | Toggle NeverDieMode |
| `@!f8` | `/aragan_key_130` | Toggle OdyAutowsMode |
| `@!f9` | `/aragan_key_131` | Toggle PetEnmityGear |
| `@!f10` | `/aragan_key_132` | Toggle PetWSGear |
| `@!f11` | `/aragan_key_133` | Toggle Redprocmode |
| `@!f12` | `/aragan_key_134` | Toggle ReEquip |
| `!^1` | `/aragan_key_135` | Toggle RefineWaltz |
| `!^2` | `/aragan_key_136` | Cycle RestingMode |
| `!^3` | `/aragan_key_137` | Toggle SalvageMode |
| `!^4` | `/aragan_key_138` | Toggle Skillchainermode |
| `!^5` | `/aragan_key_139` | Toggle SmartAutoShoutMode |
| `!^6` | `/aragan_key_140` | Toggle SmartMode |
| `!^7` | `/aragan_key_141` | Cycle Stance |
| `!^8` | `/aragan_key_142` | Toggle UnlockWeapons |
| `!^9` | `/aragan_key_143` | Toggle UseCustomTimers |
| `!^0` | `/aragan_key_144` | Toggle VWprocmode |
| `!@^f7` | `/aragan_key_145` | Toggle AutoWSMode |
| `!^f7` | `/aragan_key_146` | Toggle AutoFoodMode |
| `f6` | `/aragan_key_147` | Cycle Weapons |
| `!f6` | `/aragan_key_148` | Cycle Weapons backward |
| `@f8` | `/aragan_key_149` | Toggle AutoNukeMode |
| `^f8` | `/aragan_key_150` | Toggle AutoStunMode |
| `^!f8` | `/aragan_key_151` | Toggle AutoDefenseMode |
| `^@!f8` | `/aragan_key_152` | Toggle AutoTrustMode |
| `@pause` | `/aragan_key_153` | Cycle AutoBuffMode |
| `@scrolllock` | `/aragan_key_154` | Cycle Passive |
| `@f9` | `/aragan_key_155` | Cycle RangedMode |
| `f10` | `/aragan_key_156` | Cycle PhysicalDefenseMode; Set DefenseMode = Physical |
| `^f10` | `/aragan_key_157` | Cycle PhysicalDefenseMode |
| `@f11` | `/aragan_key_158` | Cycle CastingMode |
| `@f12` | `/aragan_key_159` | Cycle IdleMode |
| `pause` | `/aragan_key_160` | Refresh/equip the current default gear |
| `^@!pause` | `/aragan_key_161` | Run /echo [Aragan] gs org is Windower-only |
| `^@!backspace` | `/aragan_key_162` | Run /echo [Aragan] Buffup command requested |
| `@r` | `/aragan_key_163` | Set Weapons = Default |
| `^y` | `/aragan_key_164` | Toggle AutoCleanupMode |
| `^t` | `/aragan_key_165` | Cycle treasuremode |
| `!t` | `/aragan_key_166` | Run /target <bt> |
| `^o` | `/aragan_key_167` | Run /fillmode |
| `@m` | `/aragan_key_168` | Run /mount Omega |
| `^i` | `/aragan_key_169` | Toggle DarknessMode |

## Support and repositories

- Author and maintainer: **Aragan**
- Discord: https://discord.gg/TskRzqGUMG
- Profiles: https://github.com/aragan/Aragan-Ashitacast-v3-Profiles
- Ashita v4 addons: https://github.com/aragan/AshitaV4-addons
- Ashita v3 addons: https://github.com/aragan/AshitaV3-addons
- Ashitacast v3: https://github.com/aragan/Ashitacast-v3
