-- Shared Red Proc weapon selection logic for Aragan Ashita profiles.

local redproc = {}

local lock = {
    active = false,
    element = nil,
    weapon = nil,
}

local hints = {
    {
        text = 'the fiend appears vulnerable to ice elemental weapon skills!',
        weapon = 'ProcGreatSword',
        element = 'Ice',
        announcement = 'RED Proc: Ice - Freezebite(GSD)',
    },
    {
        text = 'the fiend appears vulnerable to wind elemental weapon skills!',
        weapon = 'ProcGreatKatana',
        element = 'Wind',
        announcement = 'RED Proc: Wind - Cyclone(DGR), Tachi: Jinpu(GKT)',
    },
    {
        text = 'the fiend appears vulnerable to lightning elemental weapon skills!',
        weapon = 'ProcPolearm',
        element = 'Lightning',
        announcement = 'RED Proc: Lightning - Raiden Thrust(PLM)',
    },
    {
        text = 'the fiend appears vulnerable to fire elemental weapon skills!',
        weapon = 'ProcSword',
        element = 'Fire',
        announcement = 'RED Proc: Fire - Red Lotus Blade(SWD)',
    },
    {
        text = 'the fiend appears vulnerable to earth elemental weapon skills!',
        weapon = 'ProcStaff',
        element = 'Earth',
        announcement = 'RED Proc: Earth - Earth Crusher(STF)',
    },
    {
        text = 'the fiend appears vulnerable to darkness elemental weapon skills!',
        weapon = 'ProcScythe',
        element = 'Darkness',
        announcement = 'RED Proc: Dark - Energy Drain(DGR), Shadow of Death(SCY), Blade: Ei(KTN)',
    },
    {
        text = 'the fiend appears vulnerable to light elemental weapon skills!',
        weapon = 'ProcSword2',
        element = 'Light',
        announcement = 'RED Proc: Light - Seraph Blade(SWD), Tachi: Koki(GKT), Seraph Strike(CLB), Sunburst(STF)',
    },
}

local rotations = {
    Light = {
        { ws = 'Seraph Blade', weapon = 'ProcClub' },
        { ws = 'Seraph Strike', weapon = 'ProcStaff2' },
        { ws = 'Sunburst', weapon = 'ProcGreatKatana2' },
        { ws = 'Tachi: Koki', weapon = 'ProcSword2' },
    },
    Wind = {
        { ws = 'Tachi: Jinpu', weapon = 'ProcDagger2' },
        { ws = 'Cyclone', weapon = 'ProcGreatKatana' },
    },
    Darkness = {
        { ws = 'Shadow of Death', weapon = 'ProcDagger' },
        { ws = 'Energy Drain', weapon = 'ProcKatana' },
        { ws = 'Blade: Ei', weapon = 'ProcScythe' },
    },
}

local function clear_lock()
    lock.active = false
    lock.element = nil
    lock.weapon = nil
end

local function use_weapon(name, callbacks)
    lock.weapon = name
    if callbacks and callbacks.set_weapon then
        callbacks.set_weapon(name)
    end
end

local function weapon_skill_was_used(message, ws)
    return message:find(' uses ' .. string.lower(ws), 1, true) ~= nil
end

function redproc.reset()
    clear_lock()
end

function redproc.handle(message, enabled, callbacks)
    if not enabled then
        clear_lock()
        return
    end

    local lower = string.lower(tostring(message or ''))
    if lower == '' then
        return
    end

    if lower:find('the fiend is frozen in its tracks.', 1, true) then
        use_weapon('ProcSword3', callbacks)
        clear_lock()
        if callbacks and callbacks.queue then
            callbacks.queue('/p Stagger! <call21>!')
        end
        if callbacks and callbacks.echo then
            callbacks.echo('Stagger!')
        end
        return
    end

    for _, hint in ipairs(hints) do
        if lower:find(hint.text, 1, true) then
            lock.active = true
            lock.element = hint.element
            use_weapon(hint.weapon, callbacks)
            if callbacks and callbacks.queue then
                callbacks.queue('/p ' .. hint.announcement)
            end
            if callbacks and callbacks.echo then
                callbacks.echo(hint.announcement)
            end
            return
        end
    end

    if not lock.active or lower:find('abort:', 1, true) then
        return
    end

    for _, step in ipairs(rotations[lock.element] or {}) do
        if weapon_skill_was_used(lower, step.ws) then
            use_weapon(step.weapon, callbacks)
            return
        end
    end
end

return redproc
